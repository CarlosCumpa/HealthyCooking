package com.upc.backendhealthycooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendHealthyCookingApplicationTests {

    @Test
    void contextLoads() {
    }

}
