package com.upc.backendhealthycooking.repository;

import com.upc.backendhealthycooking.entities.MetodoPago;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MetodoPagoRepository extends JpaRepository<MetodoPago,Long> {
    //List<MetodoPago> findMetodoPagoByTarjetaCreditoStartingWith(String prefix); //
}
