package com.upc.backendhealthycooking.controller;

import com.upc.backendhealthycooking.dtos.MetodoPagoDTO;
import com.upc.backendhealthycooking.entities.MetodoPago;
import com.upc.backendhealthycooking.services.MetodoPagoService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class MetodoPagoController {
    @Autowired
    private MetodoPagoService mService;
    @PostMapping("/mp") // peticion tipo POST http://localhost:8080/api/mp
    public ResponseEntity<MetodoPagoDTO> save(@RequestBody MetodoPagoDTO mpDTO){ //wrapper
        MetodoPago m;
        m = converToEntity(mpDTO);      //Convirtiendo DTO a Entity
       mpDTO= convertToDto(mService.save(m));         //Convirtiendo a Entity
        return new ResponseEntity<MetodoPagoDTO>(mpDTO, HttpStatus.OK); //200 HTTP
    }
    @GetMapping("/mps") //peticion GET http://localhost:8080/api/mp
    public ResponseEntity<List<MetodoPagoDTO>> list(){
        List<MetodoPagoDTO> listDTO;
        listDTO = convertToListDto(mService.list());
        return new ResponseEntity<List<MetodoPagoDTO>>(listDTO, HttpStatus.OK);
    }
    @PutMapping("/mp")
    public ResponseEntity<MetodoPagoDTO> update(@RequestBody MetodoPagoDTO mpDTO) throws Exception {
        MetodoPago m;
        m = converToEntity(mpDTO);
        mpDTO = convertToDto(mService.update(m));
        return new ResponseEntity<MetodoPagoDTO>(mpDTO, HttpStatus.OK);
    }
    @DeleteMapping("/mp/{id}")
    public ResponseEntity<MetodoPago> delete(@PathVariable(value = "id") Long id) throws Exception {
        return new ResponseEntity<MetodoPago>(mService.delete(id), HttpStatus.OK);
    }
    /*@GetMapping("/mp/{prefijo}")
    public ResponseEntity<List<MetodoPago>>listFirsname(@PathVariable(value = "prefijo")String prefijo){
        return new ResponseEntity<List<MetodoPago>>(mService.listFirstName(prefijo), HttpStatus.OK);
    }*/
    private MetodoPago converToEntity(MetodoPagoDTO mpDTO){
        ModelMapper modelMapper = new ModelMapper();
        MetodoPago m = modelMapper.map(mpDTO, MetodoPago.class);
        return m;
    }
    private MetodoPagoDTO convertToDto(MetodoPago mp){
        ModelMapper modelMapper = new ModelMapper();
        MetodoPagoDTO m = modelMapper.map(mp, MetodoPagoDTO.class);
        return m;
    }
    private List<MetodoPagoDTO> convertToListDto(List<MetodoPago>list){
        return list.stream().map(this::convertToDto).collect(Collectors.toList());
    }
    /*private MetodoPagoDTO convertToDto(MetodoPago mp) {

        ModelMapper modelMapper =  new ModelMapper();
        MetodoPagoDTO m = modelMapper.map(mp, MetodoPagoDTO.class);
        return m;
    }


    private MetodoPagoDTO convertToEntity(MetodoPagoDTO mpDTO) {
        ModelMapper modelMapper= new ModelMapper();
        MetodoPago a = modelMapper.map(mpDTO, MetodoPago.class);
        return m;
    } */

}
