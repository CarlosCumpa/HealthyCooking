package com.upc.backendhealthycooking.services;
import com.upc.backendhealthycooking.entities.MetodoPago;
import com.upc.backendhealthycooking.repository.MetodoPagoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class MetodoPagoService {
    @Autowired
    private MetodoPagoRepository mRepository;
    @Transactional
    public MetodoPago save(MetodoPago mp) {
        return mRepository.save(mp);
    }
    public List<MetodoPago> list() {
        return mRepository.findAll();
    }
    public MetodoPago update(MetodoPago mp) throws Exception {
        mRepository.findById(mp.getId()).orElseThrow(() -> new Exception("No se actualizó"));
        return mRepository.save(mp);
    }
    public MetodoPago delete(Long id) throws Exception {
        MetodoPago mp;
        mp= mRepository.findById(id).orElseThrow(() -> new Exception("No se existe"));
        mRepository.delete(mp);
        return mp;
    }
   /* public List<MetodoPago> listFirstName(String prefijo){
        return mRepository.findMetodoPagoByTarjetaCreditoStartingWith(prefijo);
    }*/
    public MetodoPago search(Long id) throws Exception {
        return mRepository.findById(id).orElseThrow(()->new Exception("No existe"));
    }
}