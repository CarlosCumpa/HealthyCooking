package com.upc.backendhealthycooking.repository;

import com.upc.backendhealthycooking.entities.Objetivos;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ObjetivosRepository extends JpaRepository<Objetivos, Long>  {
    List<Objetivos> findAll();
    Optional<Objetivos> findById(Long id);
}
