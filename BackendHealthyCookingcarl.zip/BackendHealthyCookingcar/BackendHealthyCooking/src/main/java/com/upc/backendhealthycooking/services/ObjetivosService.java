package com.upc.backendhealthycooking.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.upc.backendhealthycooking.dtos.ObjetivosDTO;
import com.upc.backendhealthycooking.entities.Objetivos;
import com.upc.backendhealthycooking.repository.ObjetivosRepository;


@Service
public class ObjetivosService {
    @Autowired
    ObjetivosRepository objetivosRepository;

    @Transactional(readOnly = true)
    public List<ObjetivosDTO> getAllObjetivos(){
        List<ObjetivosDTO> objetivosDTOList = new ArrayList<ObjetivosDTO>();
        List<Objetivos> objetivosList = objetivosRepository.findAll();
        for (Objetivos objetivos : objetivosList) {
            ObjetivosDTO objetivosDTO = new ObjetivosDTO();
            objetivosDTO.setId(objetivos.getId());
            objetivosDTO.setDescripcion(objetivos.getDescripcion());
            objetivosDTO.setPeriodo(objetivos.getPeriodo());
            objetivosDTOList.add(objetivosDTO);
        }
        return objetivosDTOList;
    }

    @Transactional(readOnly = true)
    public ObjetivosDTO getObjetivosById(Long id){
        ObjetivosDTO objetivosDTO = new ObjetivosDTO();
        Objetivos objetivos = objetivosRepository.findById(id).get();
        objetivosDTO.setId(objetivos.getId());
        objetivosDTO.setDescripcion(objetivos.getDescripcion());
        objetivosDTO.setPeriodo(objetivos.getPeriodo());
        return objetivosDTO;
    }

    @Transactional
    public ObjetivosDTO createObjetivos (ObjetivosDTO objetivosDTO){
        Objetivos objetivos = new Objetivos();
        objetivos.setDescripcion(objetivosDTO.getDescripcion());
        objetivos.setPeriodo(objetivosDTO.getPeriodo());
        objetivosRepository.save(objetivos);
        objetivosDTO.setId(objetivos.getId());
        return objetivosDTO;
    }

    @Transactional
    public ObjetivosDTO updateObjetivos (ObjetivosDTO objetivosDTO){
        Objetivos objetivos = objetivosRepository.findById(objetivosDTO.getId()).orElse(null);
        if (objetivos == null) {
            return null;
        }
        objetivos.setDescripcion(objetivosDTO.getDescripcion());
        objetivos.setPeriodo(objetivosDTO.getPeriodo());
        objetivosRepository.save(objetivos);
        return objetivosDTO;
    }

    @Transactional
    public ObjetivosDTO deleteObjetivos(Long id){
        Objetivos objetivos = objetivosRepository.findById(id).orElse(null);
        if (objetivos == null) {
            return null;
        }
        objetivosRepository.delete(objetivos);
        ObjetivosDTO objetivosDTO = new ObjetivosDTO();
        objetivosDTO.setId(objetivos.getId());
        objetivosDTO.setDescripcion(objetivos.getDescripcion());
        objetivosDTO.setPeriodo(objetivos.getPeriodo());
        return objetivosDTO;
    }
}
