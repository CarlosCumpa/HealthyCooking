package com.upc.backendhealthycooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.upc.backendhealthycooking.dtos.ObjetivosDTO;
import com.upc.backendhealthycooking.services.ObjetivosService;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ObjetivosController {
    @Autowired
    private ObjetivosService objetivosService;

    @GetMapping("/objetivos")
    public ResponseEntity<List<ObjetivosDTO>> getAllObjetivosDTO() {
        return new ResponseEntity<List<ObjetivosDTO>>(
                objetivosService.getAllObjetivos(), HttpStatus.OK);
    }

    @GetMapping("/objetivos/{userId}")
    public ResponseEntity<ObjetivosDTO> getAllEmploymentsDTOByUserId(
            @Param("id") Long id) {
        return new ResponseEntity<ObjetivosDTO>(
                objetivosService.getObjetivosById(id), HttpStatus.OK);
    }

    @PostMapping("/objetivos")
    public ResponseEntity<ObjetivosDTO> createObjetivosDTO(
            @RequestBody ObjetivosDTO objetivosDTO, @Param("id") Long id) {
        return new ResponseEntity<ObjetivosDTO>(
                objetivosService.createObjetivos(objetivosDTO), HttpStatus.CREATED);
    }

    @PutMapping("/objetivos")
    public ResponseEntity<ObjetivosDTO> updateObjetivosDTO(
            @RequestBody ObjetivosDTO objetivosDTO, @Param("id") Long id) {
        return new ResponseEntity<ObjetivosDTO>(
                objetivosService.updateObjetivos(objetivosDTO), HttpStatus.OK);
    }

    @DeleteMapping("/objetivos")
    public ResponseEntity<ObjetivosDTO> deleteObjetivosDTO(
            @Param("id") Long id) {
        return new ResponseEntity<ObjetivosDTO>(
                objetivosService.deleteObjetivos(id), HttpStatus.NO_CONTENT);
    }
}
